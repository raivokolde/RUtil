#' A set of useful functions by Raivo
#' 
#' @name RUtil-package
#' @docType package
#' 
#' @import stringr ggplot2 RCurl
#' 
NA